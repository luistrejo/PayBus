package com.tec2.paybus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegisterUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
    }
}
